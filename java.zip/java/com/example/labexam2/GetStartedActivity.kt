package com.example.labexam2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class GetStartedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_getstart)

        // Find the Next Button
        val nextButton: Button = findViewById(R.id.getStartedButton)

        // Navigate to LoginActivity when clicked
        nextButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java) // Ensure LoginActivity exists
            startActivity(intent)
        }
    }
}
