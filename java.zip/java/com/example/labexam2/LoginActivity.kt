package com.example.labexam2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login) // Set the layout for the login screen

        // Find the UI elements
        val usernameEditText: EditText = findViewById(R.id.username)
        val passwordEditText: EditText = findViewById(R.id.password)
        val loginButton: Button = findViewById(R.id.loginButton)
        val signupText: TextView = findViewById(R.id.signupText)

        // Set the action for the login button
        loginButton.setOnClickListener {
            val email = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Log the input values for debugging purposes
            Log.d("LoginActivity", "Email: $email, Password: $password")

            // Validate email and password
            if (isValidEmail(email) && password.isNotEmpty()) {
                // Show login success message
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()

                // Navigate to HomeActivity
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)

                // Finish this activity to prevent the user from going back to the login screen
                finish()
            } else {
                // Show error messages if validation fails
                if (!isValidEmail(email)) {
                    usernameEditText.error = "Please enter a valid email address"
                }
                if (password.isEmpty()) {
                    passwordEditText.error = "Password cannot be empty"
                }
            }
        }

        // Set the action for the "Sign Up" text
        signupText.setOnClickListener {
            // Navigate to SignUpActivity when the "Sign Up" text is clicked
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }
    }

    // Function to validate email using regular expression
    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}
