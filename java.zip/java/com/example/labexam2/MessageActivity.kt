package com.example.labexam2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MessageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)

        // Get references to the views
        val sendButton: Button = findViewById(R.id.sendButton)
        val messageInput: EditText = findViewById(R.id.editTextMessage)

        // Set OnClickListener for the send button
        sendButton.setOnClickListener {
            val message = messageInput.text.toString()

            if (message.isNotEmpty()) {
                // Show a Toast message indicating the message has been sent
                Toast.makeText(this, "Message Sent: $message", Toast.LENGTH_SHORT).show()

                // Optionally, you can clear the input field after sending the message
                messageInput.text.clear()
            } else {
                // Show a Toast if the message input is empty
                Toast.makeText(this, "Please type a message before sending.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
