package com.example.labexam2

import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MeditationActivity : AppCompatActivity() {

    private lateinit var timeDisplay: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button

    private var meditationTimeInMillis: Long = 15 * 60 * 1000 // Max 15 min (for reference)
    private var countUpTimer: CountDownTimer? = null
    private var timeElapsed: Long = 0 // Start from 0
    private var isRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meditation)

        timeDisplay = findViewById(R.id.timeDisplay)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        stopButton = findViewById(R.id.stopButton)

        startButton.setOnClickListener { startMeditation() }
        pauseButton.setOnClickListener { pauseMeditation() }
        stopButton.setOnClickListener { stopMeditation() }

        updateTimerDisplay(timeElapsed)
    }

    private fun startMeditation() {
        if (!isRunning) {
            countUpTimer = object : CountDownTimer(meditationTimeInMillis, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    timeElapsed += 1000 // Increase time
                    updateTimerDisplay(timeElapsed)
                }

                override fun onFinish() {
                    isRunning = false
                    showMeditationSummary()
                }
            }.start()
            isRunning = true
        }
    }

    private fun pauseMeditation() {
        countUpTimer?.cancel()
        isRunning = false
    }

    private fun stopMeditation() {
        countUpTimer?.cancel()
        isRunning = false
        showMeditationSummary()
        timeElapsed = 0 // Reset to 00:00
        updateTimerDisplay(timeElapsed)
    }

    private fun updateTimerDisplay(timeInMillis: Long) {
        val minutes = (timeInMillis / 1000) / 60
        val seconds = (timeInMillis / 1000) % 60
        timeDisplay.text = String.format("%02d:%02d", minutes, seconds)
    }

    private fun showMeditationSummary() {
        val minutesMeditated = (timeElapsed / 1000) / 60
        val secondsMeditated = (timeElapsed / 1000) % 60
        val timeMeditated = String.format("%02d:%02d", minutesMeditated, secondsMeditated)

        AlertDialog.Builder(this)
            .setTitle("Meditation Summary")
            .setMessage("You meditated for: $timeMeditated minutes")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}
