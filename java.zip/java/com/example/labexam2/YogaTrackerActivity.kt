package com.example.labexam2

import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class YogaTrackerActivity : AppCompatActivity() {

    private lateinit var timeDisplay: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button

    private var yogaTimeInMillis: Long = 20 * 60 * 1000 // 20 minutes max
    private var countUpTimer: CountDownTimer? = null
    private var timeElapsed: Long = 0 // Start from 0
    private var isRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_yoga_tracker)

        timeDisplay = findViewById(R.id.timeDisplay)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        stopButton = findViewById(R.id.stopButton)

        startButton.setOnClickListener { startYogaSession() }
        pauseButton.setOnClickListener { pauseYogaSession() }
        stopButton.setOnClickListener { stopYogaSession() }

        updateTimerDisplay(timeElapsed)
    }

    private fun startYogaSession() {
        if (!isRunning) {
            countUpTimer = object : CountDownTimer(yogaTimeInMillis, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    timeElapsed += 1000 // Increase time
                    updateTimerDisplay(timeElapsed)
                }

                override fun onFinish() {
                    isRunning = false
                    showYogaSummary()
                }
            }.start()
            isRunning = true
        }
    }

    private fun pauseYogaSession() {
        countUpTimer?.cancel()
        isRunning = false
    }

    private fun stopYogaSession() {
        countUpTimer?.cancel()
        isRunning = false
        showYogaSummary()
        timeElapsed = 0 // Reset to 00:00
        updateTimerDisplay(timeElapsed)
    }

    private fun updateTimerDisplay(timeInMillis: Long) {
        val minutes = (timeInMillis / 1000) / 60
        val seconds = (timeInMillis / 1000) % 60
        timeDisplay.text = String.format("%02d:%02d", minutes, seconds)
    }

    private fun showYogaSummary() {
        val minutesPracticed = (timeElapsed / 1000) / 60
        val secondsPracticed = (timeElapsed / 1000) % 60
        val timePracticed = String.format("%02d:%02d", minutesPracticed, secondsPracticed)

        AlertDialog.Builder(this)
            .setTitle("Yoga Session Summary")
            .setMessage("You practiced yoga for: $timePracticed minutes")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}