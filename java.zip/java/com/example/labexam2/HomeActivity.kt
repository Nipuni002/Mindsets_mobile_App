package com.example.labexam2

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.labexam2.YogaActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }

    // Navigation Methods
    fun openRelaxMusic(view: View) {
        startActivity(Intent(this, RelaxMusicActivity::class.java))
    }

    fun openYoga(view: View) {
        startActivity(Intent(this, YogaActivity::class.java))
    }
    fun openSleep(view: View) {
        startActivity(Intent(this, SleepActivity::class.java))
    }

    fun openMeditation(view: View) {
        startActivity(Intent(this, MeditationActivity::class.java))
    }
    fun openProfile(view: View) {
        startActivity(Intent(this, ProfileActivity::class.java))
    }


}
