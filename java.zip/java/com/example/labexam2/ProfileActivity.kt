package com.example.labexam2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Find the Messages button by ID
        val messagesBtn: Button = findViewById(R.id.messagesBtn)

        // Set OnClickListener for the Messages Button
        messagesBtn.setOnClickListener {
            // Create an intent to navigate to MessageActivity
            val intent = Intent(this, MessageActivity::class.java)
            startActivity(intent)
        }
    }
}
