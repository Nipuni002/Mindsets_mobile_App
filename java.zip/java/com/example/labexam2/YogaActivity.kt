package com.example.labexam2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class YogaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_yoga)


    }

    fun openMorningYoga(view: android.view.View) {
        val intent = Intent(this, YogaTrackerActivity::class.java)
        startActivity(intent)
    }

}
