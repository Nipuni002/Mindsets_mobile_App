package com.example.labexam2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.labexam2.HomeActivity
import com.example.labexam2.MessageActivity
import com.example.labexam2.ProfileActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class NavigationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nav)

        // Initialize Bottom Navigation View
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        // Set up item selected listener
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Open HomeActivity when 'Home' is selected
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.nav_messages -> {
                    // Open MessageActivity when 'Messages' is selected
                    startActivity(Intent(this, MessageActivity::class.java))
                    true
                }
                R.id.nav_profile -> {
                    // Open ProfileActivity when 'Profile' is selected
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }

        // By default, open HomeActivity when the app is launched
        bottomNavigationView.selectedItemId = R.id.nav_home
    }
}
