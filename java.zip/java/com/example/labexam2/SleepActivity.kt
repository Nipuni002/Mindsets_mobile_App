package com.example.labexam2

import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SleepActivity : AppCompatActivity() {

    private lateinit var timeDisplay: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button

    private var seconds = 0
    private var running = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sleep_tracker)

        timeDisplay = findViewById(R.id.timeDisplay)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        stopButton = findViewById(R.id.stopButton) // Ensure stopButton exists in XML

        startButton.setOnClickListener { startTimer() }
        pauseButton.setOnClickListener { pauseTimer() }
        stopButton.setOnClickListener { stopTimer() }
    }

    private fun startTimer() {
        if (!running) {
            running = true
            runTimer()
        }
    }

    private fun pauseTimer() {
        running = false
    }

    private fun stopTimer() {
        running = false

        // Convert seconds into HH:MM:SS format
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        val sleepTime = String.format("%02d:%02d:%02d", hours, minutes, secs)

        // Show popup dialog with sleep time
        showSleepTimePopup(sleepTime)

        // Reset timer
        seconds = 0
        timeDisplay.text = "00:00"
    }

    private fun runTimer() {
        handler.post(object : Runnable {
            override fun run() {
                val minutes = seconds / 60
                val secs = seconds % 60
                timeDisplay.text = String.format("%02d:%02d", minutes, secs)
                if (running) {
                    seconds++
                }
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun showSleepTimePopup(sleepTime: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Sleep Time Summary")
        builder.setMessage("You slept for: $sleepTime")
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }
}
